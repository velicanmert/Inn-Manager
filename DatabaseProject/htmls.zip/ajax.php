# ajax.php
$contents = '<table class="table table-hover">
    <thead>
        <tr>
            <th>Sound</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Bzzz Bzz</td>
        </tr>
    </tbody>
</table>';

echo json_encode($content);